To run this code you must have opencv/Python already 
installed on your machine. You can choose to run the 
code through Canopy, but to do it through the terminal 
on mac just:

1. Download the file onto your computer and save on the desktop
2. Open the terminal and type cd desktop and hit enter
3. Type cd micahdg_HW4 and hit enter
4. Get the file paths for the three images and paste them into lines 13-15
	(To get the full path drag the image onto the termial and the full path will appear)
	(Hopefully you can figure out which image path goes where)
	(The three images are in the original_images folder)
5. Between lines 23 and 35 uncomment the img and threshold variables for the image you want to use. 
6. Type python3 homework4.py in the terminal, hit enter, and the program should run