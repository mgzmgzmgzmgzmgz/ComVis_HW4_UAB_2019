import cv2
import numpy as np
from matplotlib import pyplot as plt
import math

#Micah Giles
#Computer Vision
#Homework 4

################################################################################
#Image paths 
#YOU WILL NEED TO CHANGE THESE TO RUN THIS CODE ON YOUR MACHINE
brick_wall = "/Users/micahgiles/Desktop/Desktop/UAB_Spring_19/Computer_Vision/ComViz_HW4_Folder/brick_wall.jpg"
mies_van_der_rohe = "/Users/micahgiles/Desktop/Desktop/UAB_Spring_19/Computer_Vision/ComViz_HW4_Folder/mies_van_der_rohe_chicago_federal_center.jpg"
sein_thug = "/Users/micahgiles/Desktop/Desktop/UAB_Spring_19/Computer_Vision/ComViz_HW4_Folder/seinfeld-yungthug.jpg"
#YOU WILL NEED TO CHANGE THESE TO RUN THIS CODE ON YOUR MACHINE
#Image paths
################################################################################


################################################################################
#Uncomment the threshold and img variable indiviually to see run each image

# img = cv2.imread(brick_wall,0)
# threshold = 7
#For brick

# img = cv2.imread(mies_van_der_rohe,0)
# threshold = 2
#For building

img = cv2.imread(sein_thug,0) 
threshold = 2.5
#For sein_thug

#Uncomment the threshold and img variable indiviually to see run each image
################################################################################


################################################################################
#Normalizing and blurring the image
norm_img = cv2.normalize(img, None, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
blr_norm_img = cv2.blur(norm_img,(5,5))
#Normalizing and blurring the image
################################################################################


################################################################################
#helper functions

def dir_calc(x, y):
    return math.atan(y/x)
    
    
def mag_calc(x, y):
    return math.sqrt((x**2) + (y**2))
    
    
def is_between_a(num, angle):
    a_min = angle - 10
    a_max = angle + 10
    if a_min <= num and a_max >= num:
        return True
    else:
        return False
        
        
def grtr_or_eq_t(num, t):
    if num >= t:
        return True
    else:
        return False


def get_sobel_and_imgshp(image):
    s_x = cv2.Sobel(image,cv2.CV_64F,1,0,ksize=5)
    s_y = cv2.Sobel(image,cv2.CV_64F,0,1,ksize=5)
    r, c = image.shape
    return [s_x, s_y, r, c]
    
    
def mk_mag_image(image):
    s_x, s_y, r, c = get_sobel_and_imgshp(image)
    result = np.zeros(image.shape)
    for i in range(r):
        for j in range(c):
            result[i,j] = mag_calc(s_x[i,j], s_y[i,j]) 
    return result
    
    
def mk_dir_image(image):
    s_x, s_y, r, c = get_sobel_and_imgshp(image)
    result = np.zeros(image.shape)
    for i in range(r):
        for j in range(c):
            result[i,j] = dir_calc(s_x[i,j], s_y[i, j]) 
    return result


def mk_thresh_image(image, dir_img, thresh):
    r, c = image.shape
    result = np.zeros(image.shape)
    for i in range(r):
        for j in range(c):
            if grtr_or_eq_t(image[i,j], thresh) and is_between_a(thresh, dir_img[i,j]) :
                result[i, j] = 1
    return result

#Helper functions
################################################################################


################################################################################
#Create, plot, and show the images

plt.subplot(2,2,1),plt.imshow(img,cmap = 'gray')
plt.title('Original'), plt.xticks([]), plt.yticks([])


dir_img = mk_dir_image(blr_norm_img)
plt.subplot(2,2,2),plt.imshow(dir_img,cmap = 'gray')
plt.title('Direction Image'), plt.xticks([]), plt.yticks([])


mag_img = mk_mag_image(blr_norm_img)
plt.subplot(2,2,3),plt.imshow(mag_img,cmap = 'gray')
plt.title('Magnitude Image'), plt.xticks([]), plt.yticks([])


thresh_img = mk_thresh_image(mag_img, dir_img, threshold)
plt.subplot(2,2,4),plt.imshow(thresh_img,cmap = 'gray')
plt.title('Threshold Image'), plt.xticks([]), plt.yticks([])


plt.show()

#Create, plot, and show the images
################################################################################


################################################################################
#Code to output images
# cv2.imwrite('brick_grey_original.png',img)
# cv2.imwrite('brick_dir_img.png',dir_img)
# cv2.imwrite('brick_mag_img.png',mag_img)
# cv2.imwrite('brick_thresh_img.png',thresh_img)
# cv2.imwrite('mies_van_der_rohe_grey_original.png',img)
# cv2.imwrite('mies_van_der_rohe_dir_img.png',dir_img)
# cv2.imwrite('mies_van_der_rohe_mag_img.png',mag_img)
# cv2.imwrite('mies_van_der_rohe_thresh_img.png',thresh_img)
# cv2.imwrite('sein_thug_grey_original.png',img)
# cv2.imwrite('sein_thug_dir_img.png',dir_img)
# cv2.imwrite('sein_thug_mag_img.png',mag_img)
# cv2.imwrite('sein_thug_thresh_img.png',thresh_img)
#Code to output images
################################################################################
